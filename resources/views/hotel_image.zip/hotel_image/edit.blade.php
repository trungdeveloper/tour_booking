@extends('_layouts.app')

@section('header')

  @include(
    '_layouts.header',
    ['title' => "Edit {$hotel_image['label']}"]
  )

@endsection


@section('content')

  @include(
    'hotel_image/_form',
    
    [
      'errors'              =>  $errors,
      'action'              =>  URL::action('Hotel_imageController@update', $hotel_image->id),
      'hotel_image'         =>  $hotel_image,
      'hotels'              =>  $hotels
    ]
  )

@endsection