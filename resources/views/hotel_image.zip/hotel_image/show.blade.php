@extends('_layouts.app')

@section('header')

  @include(
    '_layouts.header',
    ['title' => $hotel_image["name"]]
  )

@endsection


@section('content')

  <div class="my-margin-top-40 my-frame">
    <div class="my-padding-bottom-12">
      Id: {!! $hotel_image["id"] !!}
    </div>
    <div class="my-padding-bottom-12">
      Image_path: {!! $hotel_image["image_path"] !!}
    </div>
    <div class="my-padding-bottom-12">
      Is_main: {!! $hotel_image["is_main"] !!}
    </div>
    <div class="my_padding-bootom-12">
      Hotel Name: {!! $hotel_image->hotel->name !!}
    </div>
    
    <div class="d-flex flex-wrap">

      <div class="my-padding-right-8 my-padding-bottom-8">
        <a href="{!! route('hotel_images.index') !!}" class="btn btn-sm btn-outline-dark">
          <i class="far fa-arrow-alt-circle-left my-margin-right-12"></i>
          <span>Back to list of hotel_images</span>
        </a>
      </div>
      
      <div class="my-padding-bottom-8">
        <a href="{!! route('hotel_images.edit', $hotel_image["id"]) !!}" class="btn btn-sm btn-outline-primary">
          <i class="far fa-edit my-margin-right-12"></i>
          <span>Edit</span>
        </a>
      </div>

    </div>
  </div>

@endsection
