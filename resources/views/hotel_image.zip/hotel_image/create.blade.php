@extends('_layouts.app')

@section('header')

  @include(
    '_layouts.header',
    ['title' => "Add a new hotel image"]
  )

@endsection


@section('content')

  @include(
    'hotel_image/_form',
    
    [
      'errors'              =>  $errors,
      'action'              =>  URL::action('HotelImageController@store'),
      'hotel_image'         =>  $hotel_image,
      'hotels'              =>  $hotels
    ]
  )

@endsection